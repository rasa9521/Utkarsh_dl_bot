#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# (c) ACE 

import os

class Config(object):
    # get a token from @BotFather
    pass
    """
    BOT_TOKEN = os.environ.get("BOT_TOKEN", "0")
    API_ID = int(os.environ["API_ID", ]
    API_HASH = os.environ["API_HASH", "0"]
    AUTH_USERS = "7163346348 """
